package Pferde;
use strict;

sub new {
    my $class = $_[0];
    my $self = bless {} , $class;
    return $self
}

1;