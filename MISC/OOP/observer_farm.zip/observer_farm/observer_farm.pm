package observer_farm;
use strict;

sub addobserver {
    #my($self, $observer) = @_;
    print 1;#$self,"\n";
    print 2;#$observer,"\n";
    
    return
}
    
1;